## Introduction

This is a Microsoft Teams clone built with React JS and [Chat Engine](https://chatengine.io)!
Nishtha Prakash


